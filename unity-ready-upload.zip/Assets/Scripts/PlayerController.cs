using UnityEngine;

// Simple player movement script for a 2D scene (works with a sprite or cube)
public class PlayerController : MonoBehaviour
{
    public float speed = 4f;

    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        Vector3 dir = new Vector3(h, v, 0f);
        transform.position += dir * speed * Time.deltaTime;
    }
}
