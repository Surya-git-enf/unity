# Ready-to-Upload Unity Cloud ZIP (minimal template)

**What this is**
- A minimal Unity project *template* you can upload to Unity Cloud Build as a Manual Upload.
- It includes folders: Assets/, ProjectSettings/, Packages/
- It contains a simple C# script (PlayerController.cs), a placeholder scene file (text), and instructions.

**Important:** For best results, open this project in the Unity Editor on any machine (or a cloud instance),
then **open the scene and save it**. This will regenerate proper `.meta` GUIDs and a valid `.unity` scene file.
Unity Cloud Build accepts projects most reliably when the scene and meta files were created / saved by the Editor.

## Steps to use (recommended, fastest success)
1. Download and unzip this template.
2. Open Unity Hub -> "Add" -> point to the folder you unzipped (the folder containing Assets/).
3. If prompted to upgrade project to your Editor version, allow it (or create a new project using the same Editor version).
4. In the Editor: go to **Edit → Project Settings → Editor** and set **Asset Serialization → Mode** to **Force Text**.
5. Open the scene: `Assets/Scenes/MainScene.unity` (if it appears as placeholder, click it to open).
6. Press **File → Save Scenes** (this writes a valid scene file and .meta references).
7. Close the Editor and **zip the project root** so that the ZIP contains `Assets/`, `ProjectSettings/`, `Packages/` at the root (no extra parent folder).
8. In Unity Cloud Build → Manual Upload target → Upload the ZIP created in step 7.

## Alternative (connect GitHub)
- Instead of manual uploading, push this project to a GitHub repo (include Assets/, ProjectSettings/, Packages/).
- Connect the repo to Unity Cloud Build and configure the build target (WebGL).
- Ensure you commit the scene and .meta files after re-saving in the Editor (see above).

## Unity Version
- This template includes `ProjectSettings/ProjectVersion.txt` with a recommended Editor string.
- If you use a different Unity Editor, the Cloud will try to match; you can change target Editor in Cloud Build.

## Troubleshooting
- If "Manual Upload Failed": ensure your ZIP has `Assets/`, `ProjectSettings/`, `Packages/` at the top-level (no nested folder).
- If build fails with missing scripts/components: open project locally in Unity, let it compile, re-save scenes, commit and upload.
- Large builds: use GitHub + Git LFS for big binary assets.

## Files included in this template
- Assets/Scripts/PlayerController.cs  (simple player movement)
- Assets/Scenes/MainScene.unity       (text placeholder; must be re-saved in Editor)
- ProjectSettings/ProjectVersion.txt (unity version string)
- Packages/manifest.json             (minimal)
- .gitignore
